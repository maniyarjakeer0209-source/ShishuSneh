package com.example.shishusneh

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()

        setContent {
            ShishuSnehApp()
        }
    }
}

@Composable
fun ShishuSnehApp() {

    var showSplash by remember {
        mutableStateOf(true)
    }

    var showLogin by remember {
        mutableStateOf(true)
    }

    LaunchedEffect(Unit) {
        delay(2500)
        showSplash = false
    }

    when {

        showSplash -> {
            SplashScreen()
        }

        showLogin -> {
            LoginScreen(
                onLoginClick = {
                    showLogin = false
                }
            )
        }

        else -> {
            MainHomeScreen()
        }
    }
}
@Composable
fun SplashScreen() {

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F8FB)),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Surface(
                shape = RoundedCornerShape(100.dp),
                color = Color(0xFFDCEEFF)
            ) {

                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = null,
                    tint = Color(0xFF0066B2),
                    modifier = Modifier
                        .padding(30.dp)
                        .size(70.dp)
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Shishu-Sneh",
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0066B2)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Nurturing every step of your baby's journey",
                color = Color.Gray,
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(40.dp))

            CircularProgressIndicator(
                color = Color(0xFF0066B2)
            )
        }
    }
}
@Composable
fun LoginScreen(
    onLoginClick: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val auth = FirebaseAuth.getInstance()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8FA))
            .padding(24.dp),

        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Surface(
            shape = RoundedCornerShape(100.dp),
            color = Color(0xFFDCEEFF)
        ) {

            Icon(
                imageVector = Icons.Default.Face,
                contentDescription = null,
                tint = Color(0xFF0066B2),
                modifier = Modifier
                    .padding(28.dp)
                    .size(70.dp)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "Welcome Back 👋",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0066B2)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Login to continue caring for your baby",
            color = Color.Gray,
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(40.dp))

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Email Address")
            },
            leadingIcon = {
                Icon(Icons.Default.Email, null)
            },
            shape = RoundedCornerShape(20.dp)
        )

        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Password")
            },
            leadingIcon = {
                Icon(Icons.Default.Lock, null)
            },
            trailingIcon = {
                Icon(Icons.Default.Visibility, null)
            },
            shape = RoundedCornerShape(20.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {

            Text(
                text = "Forgot Password?",
                color = Color(0xFF0066B2)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener {

                        if (it.isSuccessful) {
                            onLoginClick()
                        }
                    }
            },

            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),

            shape = RoundedCornerShape(22.dp),

            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF0066B2)
            )
        ) {

            Text(
                text = "LOGIN",
                fontSize = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedButton(
            onClick = {
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener {

                        if (it.isSuccessful) {
                            onLoginClick()
                        }
                    }
            },

            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),

            shape = RoundedCornerShape(22.dp)
        ) {

            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "Create Account"
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        Text(
            text = "Trusted by 10,000+ parents ❤️",
            color = Color.Gray
        )
    }
}
@Composable
fun MainHomeScreen() {

    var selectedTab by remember {
        mutableIntStateOf(0)
    }

    Scaffold(

        containerColor = Color(0xFFF7F8FA),

        floatingActionButton = {

            FloatingActionButton(
                onClick = { },
                containerColor = Color(0xFF0066B2)
            ) {

                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        },

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = {
                        selectedTab = 0
                    },
                    icon = {
                        Icon(Icons.Default.Home, null)
                    },
                    label = {
                        Text("Home")
                    }
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                    },
                    icon = {
                        Icon(Icons.Default.Vaccines, null)
                    },
                    label = {
                        Text("Vaccine")
                    }
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = {
                        selectedTab = 2
                    },
                    icon = {
                        Icon(Icons.Default.ShowChart, null)
                    },
                    label = {
                        Text("Growth")
                    }
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = {
                        selectedTab = 3
                    },
                    icon = {
                        Icon(Icons.Default.Restaurant, null)
                    },
                    label = {
                        Text("Feeding")
                    }
                )

                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = {
                        selectedTab = 4
                    },
                    icon = {
                        Icon(Icons.Default.Star, null)
                    },
                    label = {
                        Text("Milestones")
                    }
                )
                NavigationBarItem(
                    selected = selectedTab == 5,
                    onClick = {
                        selectedTab = 5
                    },
                    icon = {
                        Icon(Icons.Default.Person, null)
                    },
                    label = {
                        Text("Profile")
                    }
                )
            }
        }

    ) { padding ->

        when (selectedTab) {

            0 -> HomeScreen(padding)
            1 -> VaccineScreen(padding)
            2 -> GrowthScreen(padding)
            3 -> FeedingScreen(padding)
            4 -> MilestoneScreen(padding)
            5 -> ProfileScreen(padding)
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Shishu-Sneh",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = Color(0xFF0066B2),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Hello, Aarav 👋",
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0066B2)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "4 Months • 12 Days Old",
                color = Color.Gray,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            PremiumCard(
                title = "NEXT VACCINE",
                subtitle = "DTP Booster 1",
                extra = "Next Week",
                bgColor = Color(0xFFDCEEFF)
            )

            Spacer(modifier = Modifier.height(16.dp))

            PremiumCard(
                title = "LAST FEEDING",
                subtitle = "150ml Breast Milk",
                extra = "2h ago",
                bgColor = Color(0xFFF1F4F7)
            )

            Spacer(modifier = Modifier.height(16.dp))

            PremiumCard(
                title = "GROWTH SUMMARY",
                subtitle = "6.2 kg • 64 cm",
                extra = "+0.4kg",
                bgColor = Color(0xFFFFEEF4)
            )

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Quick Actions",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                ActionButton("Daily Log", Icons.Default.Edit)

                ActionButton("Reminders", Icons.Default.Notifications)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                ActionButton("Guides", Icons.Default.Book)

                ActionButton("Add New", Icons.Default.Add)
            }

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Recent Activity",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "View All",
                    color = Color(0xFF0066B2)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            RecentActivityCard(
                title = "Morning Nap",
                subtitle = "10:30 AM - 11:45 AM"
            )

            Spacer(modifier = Modifier.height(12.dp))

            RecentActivityCard(
                title = "Diaper Change",
                subtitle = "09:15 AM • Wet"
            )

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun PremiumCard(
    title: String,
    subtitle: String,
    extra: String,
    bgColor: Color
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = bgColor
        )
    ) {

        Column(
            modifier = Modifier.padding(22.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = title,
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF0066B2)
                ) {

                    Text(
                        text = extra,
                        color = Color.White,
                        modifier = Modifier.padding(
                            horizontal = 14.dp,
                            vertical = 6.dp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = subtitle,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ActionButton(
    text: String,
    icon: ImageVector
) {

    Card(
        modifier = Modifier
            .width(160.dp)
            .height(130.dp),
        shape = RoundedCornerShape(24.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFFDCEEFF)
            ) {

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF0066B2),
                    modifier = Modifier.padding(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(text = text)
        }
    }
}

@Composable
fun RecentActivityCard(
    title: String,
    subtitle: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {

        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFFDCEEFF)
            ) {

                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = null,
                    tint = Color(0xFF0066B2),
                    modifier = Modifier.padding(12.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {

                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun VaccineScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Shishu-Sneh",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = Color(0xFF0066B2),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            // UPCOMING CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFDCEEFF)
                )
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text(
                        text = "Upcoming Milestone",
                        fontSize = 20.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "10-Week Vaccinations",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0066B2)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFF0066B2)
                    ) {

                        Row(
                            modifier = Modifier.padding(
                                horizontal = 18.dp,
                                vertical = 10.dp
                            ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = null,
                                tint = Color.White
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "Due in 4 Days",
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // TABS
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                VaccineTab("All Schedules", true)
                VaccineTab("Due Now", false)
                VaccineTab("Upcoming", false)
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Action Required",
                color = Color.Red,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(18.dp))

            // DUE CARD
            VaccineCard(
                title = "OPV & IPV 1",
                subtitle = "Polio Vaccine • Dose 1",
                dueDate = "Scheduled: Oct 24, 2023",
                action = "LOG DOSE",
                due = true
            )

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Upcoming",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(18.dp))

            VaccineCard(
                title = "BCG",
                subtitle = "Tuberculosis Protection",
                dueDate = "Due: Nov 12, 2023",
                action = "VIEW INFO",
                due = false
            )

            Spacer(modifier = Modifier.height(16.dp))

            VaccineCard(
                title = "Rotavirus",
                subtitle = "Dose 2 of 3",
                dueDate = "Due: Nov 28, 2023",
                action = "REMAP DATE",
                due = false
            )

            Spacer(modifier = Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Recently Completed",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "See All",
                    color = Color(0xFF0066B2)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {

                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF0066B2)
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {

                        Text(
                            text = "Hepatitis B",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Completed Sep 15, 2023",
                            color = Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun VaccineTab(
    text: String,
    selected: Boolean
) {

    Surface(
        shape = RoundedCornerShape(50),
        color = if (selected)
            Color(0xFF0066B2)
        else
            Color(0xFFDCEEFF)
    ) {

        Text(
            text = text,
            color = if (selected)
                Color.White
            else
                Color.DarkGray,
            modifier = Modifier.padding(
                horizontal = 18.dp,
                vertical = 10.dp
            )
        )
    }
}

@Composable
fun VaccineCard(
    title: String,
    subtitle: String,
    dueDate: String,
    action: String,
    due: Boolean
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {

        Column(
            modifier = Modifier.padding(20.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Column {

                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = subtitle,
                        color = Color.Gray
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (due)
                        Color(0xFFFFD6D6)
                    else
                        Color(0xFFDCEEFF)
                ) {

                    Text(
                        text = if (due) "DUE" else "UPCOMING",
                        color = if (due)
                            Color.Red
                        else
                            Color(0xFF0066B2),
                        modifier = Modifier.padding(
                            horizontal = 12.dp,
                            vertical = 6.dp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = dueDate,
                    color = Color.Gray
                )

                Text(
                    text = action,
                    color = Color(0xFF0066B2),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun GrowthScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Shishu-Sneh",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = Color(0xFF0066B2),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // LATEST MEASUREMENT
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFDCEEFF)
                )
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text(
                        text = "LATEST MEASUREMENT",
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "8.4 kg",
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Measured 2 days ago",
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.White
                    ) {

                        Text(
                            text = "+0.2kg",
                            color = Color(0xFF0066B2),
                            modifier = Modifier.padding(
                                horizontal = 14.dp,
                                vertical = 8.dp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Log Growth",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                GrowthInputCard(
                    title = "Weight",
                    value = "8.4",
                    unit = "kg"
                )

                GrowthInputCard(
                    title = "Height",
                    value = "72",
                    unit = "cm"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066B2)
                )
            ) {

                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Save Record",
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            // GRAPH CARD
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Weight Over Time",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Text(
                        text = "WHO Standard",
                        modifier = Modifier.padding(
                            horizontal = 14.dp,
                            vertical = 8.dp
                        ),
                        color = Color(0xFF0066B2)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                shape = RoundedCornerShape(28.dp)
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {

                    repeat(5) {

                        Divider(
                            color = Color.LightGray
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {

                        Text("Birth")
                        Text("3m")
                        Text("6m")
                        Text("9m")
                        Text("12m")
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // INSIGHT CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp)
            ) {

                Row(
                    modifier = Modifier.padding(22.dp)
                ) {

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color(0xFFDCEEFF)
                    ) {

                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = Color(0xFF0066B2),
                            modifier = Modifier
                                .padding(16.dp)
                                .size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {

                        Text(
                            text = "Growth Insight",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Aarav is currently in the 75th percentile for weight. This is within healthy range according to WHO standards.",
                            color = Color.Gray,
                            lineHeight = 24.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // PAST RECORDS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Past Records",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "View All",
                    color = Color(0xFF0066B2)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            PastRecordCard(
                date = "Oct 12, 2023",
                weight = "8.4 kg",
                height = "72 cm"
            )

            Spacer(modifier = Modifier.height(14.dp))

            PastRecordCard(
                date = "Sep 15, 2023",
                weight = "8.1 kg",
                height = "70 cm"
            )

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun GrowthInputCard(
    title: String,
    value: String,
    unit: String
) {

    Card(
        modifier = Modifier
            .width(170.dp)
            .height(130.dp),
        shape = RoundedCornerShape(22.dp)
    ) {

        Column(
            modifier = Modifier.padding(18.dp)
        ) {

            Text(
                text = title,
                color = Color(0xFF0066B2),
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.Bottom
            ) {

                Text(
                    text = value,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = unit,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun PastRecordCard(
    date: String,
    weight: String,
    height: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {

        Row(
            modifier = Modifier.padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Column {

                Text(
                    text = date,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "10 months old",
                    color = Color.Gray
                )
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {

                Text(
                    text = weight,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = height,
                    color = Color(0xFFB00020)
                )
            }
        }
    }
}

@Composable
fun FeedingScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Shishu-Sneh",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = Color(0xFF0066B2),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // FEEDING STATUS CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFDCEEFF)
                )
            ) {

                Column(
                    modifier = Modifier.padding(26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "Next Feeding In",
                        color = Color.Gray,
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "01 : 24 : 12",
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0066B2)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.White
                    ) {

                        Text(
                            text = "Breast Feeding",
                            color = Color(0xFF0066B2),
                            modifier = Modifier.padding(
                                horizontal = 18.dp,
                                vertical = 10.dp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Quick Actions",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                FeedingActionCard(
                    title = "Start Feeding",
                    icon = Icons.Default.PlayArrow
                )

                FeedingActionCard(
                    title = "Bottle Feed",
                    icon = Icons.Default.LocalDrink
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                FeedingActionCard(
                    title = "Add Formula",
                    icon = Icons.Default.Add
                )

                FeedingActionCard(
                    title = "Feeding Notes",
                    icon = Icons.Default.Edit
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Text(
                    text = "Today's Summary",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "View Details",
                    color = Color(0xFF0066B2)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            SummaryCard(
                title = "Total Feedings",
                value = "7"
            )

            Spacer(modifier = Modifier.height(14.dp))

            SummaryCard(
                title = "Milk Intake",
                value = "920 ml"
            )

            Spacer(modifier = Modifier.height(14.dp))

            SummaryCard(
                title = "Average Duration",
                value = "18 mins"
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Recent Feedings",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            FeedingHistoryCard(
                time = "08:45 AM",
                type = "Breast Feeding",
                duration = "22 mins"
            )

            Spacer(modifier = Modifier.height(14.dp))

            FeedingHistoryCard(
                time = "06:30 AM",
                type = "Bottle Feed",
                duration = "180 ml"
            )

            Spacer(modifier = Modifier.height(14.dp))

            FeedingHistoryCard(
                time = "03:20 AM",
                type = "Formula Feed",
                duration = "150 ml"
            )

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun FeedingActionCard(
    title: String,
    icon: ImageVector
) {

    Card(
        modifier = Modifier
            .width(170.dp)
            .height(140.dp),
        shape = RoundedCornerShape(24.dp)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFFDCEEFF)
            ) {

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF0066B2),
                    modifier = Modifier
                        .padding(16.dp)
                        .size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = title,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun SummaryCard(
    title: String,
    value: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {

        Row(
            modifier = Modifier.padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Text(
                text = title,
                fontSize = 18.sp
            )

            Text(
                text = value,
                color = Color(0xFF0066B2),
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }
    }
}

@Composable
fun FeedingHistoryCard(
    time: String,
    type: String,
    duration: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {

        Row(
            modifier = Modifier.padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Column {

                Text(
                    text = time,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = type,
                    color = Color.Gray
                )
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFFDCEEFF)
            ) {

                Text(
                    text = duration,
                    color = Color(0xFF0066B2),
                    modifier = Modifier.padding(
                        horizontal = 16.dp,
                        vertical = 10.dp
                    )
                )
            }
        }
    }
}

@Composable
fun MilestoneScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            // TOP BAR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Shishu-Sneh",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFDCEEFF)
                ) {

                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = null,
                        tint = Color(0xFF0066B2),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // HEADER CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFDCEEFF)
                )
            ) {

                Column(
                    modifier = Modifier.padding(26.dp)
                ) {

                    Text(
                        text = "Development Progress",
                        color = Color.Gray,
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "8 / 10 Milestones",
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0066B2)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    LinearProgressIndicator(
                        progress = { 0.8f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp),
                        color = Color(0xFF0066B2),
                        trackColor = Color.White
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Excellent progress for age group",
                        color = Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Achieved Milestones",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            MilestoneCard(
                title = "First Smile",
                subtitle = "Social smiling achieved",
                age = "2 Months",
                achieved = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            MilestoneCard(
                title = "Rolling Over",
                subtitle = "Can roll from tummy to back",
                age = "4 Months",
                achieved = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            MilestoneCard(
                title = "Recognizes Parents",
                subtitle = "Responds to familiar faces",
                age = "5 Months",
                achieved = true
            )

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Upcoming Milestones",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            MilestoneCard(
                title = "Sitting Without Support",
                subtitle = "Expected within 2 weeks",
                age = "6 Months",
                achieved = false
            )

            Spacer(modifier = Modifier.height(14.dp))

            MilestoneCard(
                title = "First Words",
                subtitle = "Basic sounds and words",
                age = "8 Months",
                achieved = false
            )

            Spacer(modifier = Modifier.height(32.dp))

            // DEVELOPMENT INSIGHT
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp)
            ) {

                Row(
                    modifier = Modifier.padding(22.dp)
                ) {

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFFDCEEFF)
                    ) {

                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color(0xFF0066B2),
                            modifier = Modifier
                                .padding(16.dp)
                                .size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {

                        Text(
                            text = "Development Insight",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Aarav is progressing very well according to developmental milestones recommended by pediatric specialists.",
                            color = Color.Gray,
                            lineHeight = 24.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // ACTIVITY CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFEEF4)
                )
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text(
                        text = "Recommended Activity",
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Tummy Time Exercises",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Encourage crawling strength and neck development with supervised tummy exercises.",
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { },
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0066B2)
                        )
                    ) {

                        Text("View Activity Guide")
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun MilestoneCard(
    title: String,
    subtitle: String,
    age: String,
    achieved: Boolean
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp)
    ) {

        Row(
            modifier = Modifier.padding(22.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Row {

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = if (achieved)
                        Color(0xFFDCEEFF)
                    else
                        Color(0xFFFFEEF4)
                ) {

                    Icon(
                        imageVector =
                            if (achieved)
                                Icons.Default.CheckCircle
                            else
                                Icons.Default.Schedule,

                        contentDescription = null,

                        tint =
                            if (achieved)
                                Color(0xFF0066B2)
                            else
                                Color(0xFFB00020),

                        modifier = Modifier
                            .padding(14.dp)
                            .size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {

                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = subtitle,
                        color = Color.Gray
                    )
                }
            }

            Text(
                text = age,
                color = Color(0xFF0066B2),
                fontWeight = FontWeight.Bold
            )
        }
    }
}
@Composable
fun ProfileScreen(padding: PaddingValues) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(Color(0xFFF7F8FA))
            .padding(18.dp)
    ) {

        item {

            // TOP
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )

                Text(
                    text = "Baby Profile",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0066B2)
                )

                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = Color(0xFF0066B2)
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            // PROFILE CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFDCEEFF)
                )
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(26.dp),

                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = Color.White
                    ) {

                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = null,
                            tint = Color(0xFF0066B2),
                            modifier = Modifier
                                .padding(30.dp)
                                .size(80.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))

                    Text(
                        text = "Aarav Sharma",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "10 Months Old",
                        color = Color.Gray,
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.White
                    ) {

                        Text(
                            text = "Healthy Growth",
                            color = Color(0xFF0066B2),
                            modifier = Modifier.padding(
                                horizontal = 18.dp,
                                vertical = 10.dp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Baby Information",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            ProfileInfoCard("Birth Date", "12 January 2025")
            Spacer(modifier = Modifier.height(14.dp))

            ProfileInfoCard("Blood Group", "O+ Positive")
            Spacer(modifier = Modifier.height(14.dp))

            ProfileInfoCard("Pediatrician", "Dr. Mehta")
            Spacer(modifier = Modifier.height(14.dp))

            ProfileInfoCard("Current Weight", "8.4 kg")
            Spacer(modifier = Modifier.height(14.dp))

            ProfileInfoCard("Current Height", "72 cm")

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Parent Details",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(18.dp))

            ProfileInfoCard("Mother", "Priya Sharma")
            Spacer(modifier = Modifier.height(14.dp))

            ProfileInfoCard("Emergency Contact", "+91 9876543210")

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = { },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),

                shape = RoundedCornerShape(22.dp),

                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066B2)
                )
            ) {

                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Edit Profile",
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun ProfileInfoCard(
    title: String,
    value: String
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {

        Row(
            modifier = Modifier.padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Text(
                text = title,
                color = Color.Gray,
                fontSize = 18.sp
            )

            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0066B2)
            )
        }
    }
}

@Composable
fun ScreenTemplate(
    padding: PaddingValues,
    title: String,
    subtitle: String
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(20.dp)
    ) {

        Text(
            text = title,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0066B2)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = subtitle,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(30.dp))

        repeat(4) {

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(20.dp)
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text = "Sample Data Card",
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Frontend demo ready"
                    )
                }
            }
        }
    }
}